using System;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections;

namespace TCPClient
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class TCPClient
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			TCPClient client = null;
			//client = new TCPClient("090907070718,13145826175,GPRMC,070718.000,A,2234.0228,N,11403.0764,E,0.00,,070909,,,A*73,F,,imei:354776030042714,05,50.1,F:4.11V,0,132,40512,460,01,2533,720B");
			//client = new TCPClient("#135790246811222#13486119277#1#0000#AUT#10#27bc10af#11407.4189,E,2232.7893,N,0.00,0.66#070709#132022.000#27bc10af#11407.4189,E,2232.7898,N,0.00,0.66#070709#132028.000#27bc10af#11407.4189,E,2232.7902,N,0.00,0.66#070709#132034.000#27bc10af#11407.4190,E,2232.7908,N,0.00,0.66#070709#132040.000#27bc10af#11407.4190,E,2232.7912,N,0.00,0.66#070709#132046.000#27bc10af#11407.4190,E,2232.7913,N,0.00,0.66#070709#132052.000#27bc10af#11407.4192,E,2232.7917,N,0.00,0.66#070709#132058.000#27bc10af#11407.4197,E,2232.7974,N,0.00,0.66#070709#132104.000#27bc10af#11407.4205,E,2232.7972,N,0.00,0.66#070709#132110.000#27bc10af#11407.4211,E,2232.7972,N,0.00,0.66#070709#132116.000##");
			//client = new TCPClient("090907070718,13145826175,GPRMC,070718.000,A,2234.0228,N,11403.0764,E,0.00,,070909,,,A*73,F,,imei:354776030042714,05,50.1,F:4.11V,0,132,40512,460,01,2533,720B");
			//client = new TCPClient("090907070718,13145826175,GPRMC,070718.000,A,2234.0228,N,11403.0764,E,0.00,,070909,,,A*73,F,,imei:354776030042714,05,50.1,F:4.11V,0,132,40512,460,01,2533,720B");
			//client = new TCPClient("090907070718,13145826175,GPRMC,070718.000,A,2234.0228,N,11403.0764,E,0.00,,070909,,,A*73,F,,imei:354776030042714,05,50.1,F:4.11V,0,132,40512,460,01,2533,720B");
			//client = new TCPClient("090907070718,13145826175,GPRMC,070718.000,A,2234.0228,N,11403.0764,E,0.00,,070909,,,A*73,F,,imei:354776030042714,05,50.1,F:4.11V,0,132,40512,460,01,2533,720B");
			client = new TCPClient("imei:359587010124900,tracker,0809231929,13554900601,F,112909.397,A,2234.4669,N,11354.3287,E,0.11,;");
		}

		private String m_fileName=null;
		public TCPClient(String fileName)
		{
			m_fileName=fileName;
			Thread t = new Thread(new ThreadStart(ClientThreadStart));
			t.Start();
		}

		private void ClientThreadStart()
		{
			Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp );
			clientSocket.Connect(new IPEndPoint(IPAddress.Parse("127.0.0.1"),8081));

			// Send the file name.
			clientSocket.Send(Encoding.ASCII.GetBytes(m_fileName));
			
			// Receive the length of the filename.
			byte [] data = new byte[128];
			clientSocket.Receive(data);
			int length=BitConverter.ToInt32(data,0);

			clientSocket.Send(Encoding.ASCII.GetBytes(m_fileName+":"+"this is a test\r\n"));

			clientSocket.Send(Encoding.ASCII.GetBytes(m_fileName+":"+"THIS IS "));
			clientSocket.Send(Encoding.ASCII.GetBytes("ANOTHRER "));
			clientSocket.Send(Encoding.ASCII.GetBytes("TEST."));
			clientSocket.Send(Encoding.ASCII.GetBytes("\r\n"));
			clientSocket.Send(Encoding.ASCII.GetBytes(m_fileName+":"+"TEST.\r\n"+m_fileName+":"+"TEST AGAIN.\r\n"));
			clientSocket.Send(Encoding.ASCII.GetBytes("[EOF]\r\n"));

			// Get the total length
			clientSocket.Receive(data);
			length=BitConverter.ToInt32(data,0);
			clientSocket.Close();
		}

	}
}
